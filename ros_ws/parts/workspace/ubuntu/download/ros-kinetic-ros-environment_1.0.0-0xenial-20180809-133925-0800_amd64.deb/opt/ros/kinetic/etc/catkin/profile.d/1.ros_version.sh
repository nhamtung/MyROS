# generated from ros_environment/env-hooks/1.ros_version.sh.in

export ROS_VERSION=1
