/*
 * Copyright (c) 2013      Mellanox Technologies, Inc.
 *                         All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 */

#ifndef __MPP_SHMEM_H__
#define __MPP_SHMEM_H__

#include <shmem.h>

#endif